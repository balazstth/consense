﻿
console.log("Hello");