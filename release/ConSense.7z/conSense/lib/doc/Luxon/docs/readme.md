This directory contains markdown files that get compiled into the documentation [here](https://moment.github.io/luxon/docs). You can read them here if that's your thing, but note that the links are relative to their destination in the compiled site and won't work from here.

If you add a file to this, you'll need to add to index.js too, else it won't get compiled to the site.
